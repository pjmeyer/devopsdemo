package com.microsoft.example.models;

import java.util.List;


public class Distance 
    implements java.io.Serializable
{
    
    public Distance()
    {

     }
     
             public float startingpoint;
        public float destpoint;
     
     /*
     function verify_geolocation_capability()
    {
       if (navigator.geolocation)
       {
          document.form1.capability.value = "Enabled";
       }
       else
       {
          document.form1.capability.value = "Not Enabled";
       }
    }
    
    */
     
}